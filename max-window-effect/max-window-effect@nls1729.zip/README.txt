Maximized Window Effect - Gnome Shell Extension

When a window is maximized on the primary screen the panel is set to 
opaque black.  This extension can be used in conjunction with themes
that set the panel transparent or the panel color is not compatible 
with a maximized window.

This extension is not compatible with the Activities Configurator 
Extension.

2014-11-04 Version 1. 

2014-11-11 Added logic to save the color of the icons and text on the
panel.  When the panel color is changed to black the text andicons are
changed to white.  Then the panel color is restored the original text
and icon color is restored.  Some themes can change element colors in
ways not compatible with this extension.  This change makes the extension
compatible with more themes but not all.

----
zip: 2014-11-14 12:42:57 Commit: bb33973b6109f1582c9369b7be9516c10dbbac57
